# TensorflowGUI

Dataset folder download: https://goo.gl/fAmfTP
